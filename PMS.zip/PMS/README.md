<h1>Prisoner's Management System By BOTS </h1>

<h2>Group Members:</h2>
<ul>
<li>Muhammad Ehtisham</li>
<li>Talal Zulfiqar</li>
<li>Muhammad Abdullah Nadeem</li>

</ul>

<h2>How to run Project (make sure you have the setup of Django and Python):</h2>
<ul>
<li>Download the code</li>
<li>Intsall all the requirements</li>
<li>python3 manage.py makemigrations</li>
<li>python3 manage.py migrate</li>
<li>python3 manage.py createsuperuser</li>
<li>python3 manage.py runserver</li>
<li>Visit the localhost address</li>
</ul>
